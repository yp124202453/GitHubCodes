#ifndef _CORELIB_H_
#define _CORELIB_H_

//
// Common headers
//
#include "coredefs.h"
#include "chkmacros.h"

#endif // _CORELIB_H_
