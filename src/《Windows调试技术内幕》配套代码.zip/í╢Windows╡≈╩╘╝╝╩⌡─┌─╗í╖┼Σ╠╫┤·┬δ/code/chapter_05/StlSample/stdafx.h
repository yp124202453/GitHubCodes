#pragma once 

//
// Windows Headers
//
#include <tchar.h>
#include <stdio.h>
#include <stdlib.h>
#include <windows.h>

//
// STL Headers
//
#include <algorithm>
#include <string>

//
// Common Implementation Headers
//
#include "corelib.h"
