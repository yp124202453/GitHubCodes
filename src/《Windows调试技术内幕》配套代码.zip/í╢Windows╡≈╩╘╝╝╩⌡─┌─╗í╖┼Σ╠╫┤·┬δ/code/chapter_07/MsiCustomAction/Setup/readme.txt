1- Install the Windows Installer XML (WIX) Toolset from http://wix.sourceforge.net/
2- Run compile.bat in order to re-generate the sample MSI.
