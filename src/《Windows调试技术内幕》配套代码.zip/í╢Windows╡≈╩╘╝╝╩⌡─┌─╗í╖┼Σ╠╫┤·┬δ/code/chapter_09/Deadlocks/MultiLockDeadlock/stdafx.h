#pragma once

#include <tchar.h>
#include <stdio.h>
#include <stdlib.h>
#include <windows.h>

#include <atlbase.h>
#include <atlstr.h>

#include "corelib.h"
#include "critsec.h"
