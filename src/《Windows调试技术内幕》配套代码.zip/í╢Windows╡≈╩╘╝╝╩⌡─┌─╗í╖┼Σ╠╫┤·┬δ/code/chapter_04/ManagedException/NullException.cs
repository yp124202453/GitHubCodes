using System;

public class Test
{
    public static void Main()
    {
        throw new ArgumentNullException();
    }
}
