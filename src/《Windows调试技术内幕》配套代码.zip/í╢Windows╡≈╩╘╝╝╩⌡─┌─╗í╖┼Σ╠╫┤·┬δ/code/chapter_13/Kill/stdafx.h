//
// Windows Headers
//
#include <tchar.h>
#include <stdio.h>
#include <stdlib.h>
#include <windows.h>

//
// ATL Smart Pointers
//
#include <atlbase.h>

//
// Common Implementation Headers
//
#include "corelib.h"
