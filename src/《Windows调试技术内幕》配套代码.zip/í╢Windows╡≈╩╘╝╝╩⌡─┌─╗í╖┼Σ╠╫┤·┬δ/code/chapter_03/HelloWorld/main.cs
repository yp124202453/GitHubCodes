using System;

public class Test
{
    public static void Main()
    {
        Console.WriteLine("Hello World!");
        Console.WriteLine("Press any key to continue...");
        Console.ReadLine();
        Console.WriteLine("Exiting...");
    }
}
