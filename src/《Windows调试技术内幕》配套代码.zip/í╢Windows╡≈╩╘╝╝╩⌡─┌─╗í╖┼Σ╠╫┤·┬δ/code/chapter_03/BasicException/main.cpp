#include "stdafx.h"

int
__cdecl
wmain()
{
    throw "This program raised an error";
    return 0;
}
